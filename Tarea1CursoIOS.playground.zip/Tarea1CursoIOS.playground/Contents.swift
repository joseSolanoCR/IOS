import UIKit

//------------ Ejercicio 1

class Perro{
    var nombre: String
    var color: String
    var edad: Int
    
    init(nombre: String, color:String, edad: Int){
        self.nombre = nombre
        self.color = color
        self.edad = edad
    }
}

class Persona{
    var nombre: String
    var ID: String
    var edad: Int
    var perros: [Perro]
    
    init(nombre: String, id: String, edad: Int){
        self.nombre = nombre
        self.ID = id
        self.edad = edad
        perros = [Perro]()
    }
}

//------------ Ejercicio 2
func crearPersonas(){
    let humano1 : Persona = Persona(nombre: "Juliana", id: "9999999", edad: 6)
    let humano1perro1: Perro = Perro(nombre: "Max", color: "Blanco", edad: 1)
    let humano1perro2: Perro = Perro(nombre: "Canela", color: "Baige-Blanco", edad: 8)
    humano1.perros.append(humano1perro1)
    humano1.perros.append(humano1perro2)
    
    let humano2 : Persona = Persona(nombre: "Maripaz", id: "8888888", edad: 6)
    let humano2perro1: Perro = Perro(nombre: "Coocky", color: "Beige", edad: 10)
    let humano2perro2: Perro = Perro(nombre: "Max", color: "Blanco", edad: 1)
    humano2.perros.append(humano2perro1)
    humano2.perros.append(humano2perro2)
    
    let humano3 : Persona = Persona(nombre: "Sebastian", id: "777777", edad: 6)
    let humano3perro1: Perro = Perro(nombre: "Blackie", color: "Negro", edad: 10)
    let humano3perro2: Perro = Perro(nombre: "Max", color: "Blanco", edad: 1)
    humano3.perros.append(humano3perro1)
    humano3.perros.append(humano3perro2)
    
    //Arreglo para imprimir en ciclo
    let personas = [humano1, humano2, humano3]
    var idPerro: Int;
    
    for p in personas {
        idPerro = 1
        print("Nombre: \(p.nombre)")
        print("Identificador: \(p.ID)")
        print("Edad \(p.edad)")
        print("Cantidad de perros \(p.perros.count)")
        
        
        for d in p.perros{
            print("\tPerro \(idPerro)")
            print("\t\tNombre \(d.nombre)")
            print("\t\tColor \(d.color)")
            print("\t\tEdad \(d.edad)")
            
            idPerro += 1
        }
        
        print("\n")
    }
}

crearPersonas()


//------------ Ejercicio 3
func calcularPrimos(numFinal: Int) -> [Int]{
    var resultado = [Int]()
    
    for id in 1...numFinal{
        var primo = true
        
        if (id > 1){
            for id2 in 2..<id{
                if (id % id2 == 0){
                    primo = false
                    break
                }
            }
        }
        
        if primo{
            resultado.append(id)
        }
    }
    
    return resultado
}

let primos = calcularPrimos(numFinal: 9)


//------------ Ejercicio 4
func joinOrder(array1: [Int], array2: [Int]){
    var join = array1 + array2
    
    join.sort(by: {$0 < $1})
    
    var printArray = ""
    
    for val in join {
        if (printArray != ""){
            printArray += ", "
        }
        printArray += "\(val) "
    }
    
    print (printArray)
}

var arreg1 = [5,2,7,6]
var arreg2 = [9,1,4,8]

joinOrder(array1: arreg1, array2: arreg2)
