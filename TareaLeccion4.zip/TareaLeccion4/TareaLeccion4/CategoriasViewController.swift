//
//  ViewController.swift
//  TareaLeccion4
//
//  Created by ice on 5/2/19.
//  Copyright © 2019 personal. All rights reserved.
//

import UIKit

class CategoriasViewController: UIViewController {

    @IBOutlet weak var tabla: UITableView!
    
    var categorias = [Categoria]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let catDeportes = Categoria(nombre: "Deportes", imagen: "deportes")
        let catSucesos = Categoria(nombre: "Sucesos", imagen: "sucesos")
        let catEconomia = Categoria(nombre: "Economía", imagen: "economia")
        let catTecnologia = Categoria(nombre: "Tecnología", imagen: "tecnologia")
        
        categorias.append(catSucesos)
        categorias.append(catEconomia)
        categorias.append(catDeportes)
        categorias.append(catTecnologia)
        
        registerCustomTableView()
    }

    func registerCustomTableView(){
        let nib = UINib(nibName: "CategoriasTableViewCell", bundle: nil)
        tabla.register(nib, forCellReuseIdentifier: "CategoriasTableViewCell")
    }
}

extension CategoriasViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //Se identifica como el nobre de la clase y se castea al tipo custom con el as?
        guard let celda = tableView.dequeueReusableCell(withIdentifier: "CategoriasTableViewCell") as? CategoriasTableViewCell else {
            return UITableViewCell()
        }
        
        let img: UIImage = UIImage(named: categorias[indexPath.row].imagen)!
        celda.imagen.image = img
        
        print(indexPath.row)
        
        celda.etiqueta.text = categorias[indexPath.row].nombre
        
        return celda
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80.0 //Altura de la celda
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyboard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc : NoticiasViewController = storyboard.instantiateViewController(withIdentifier: "NoticiasViewController") as! NoticiasViewController
        
        let navController = UINavigationController(rootViewController: vc)
        
        vc.categoria = categorias[indexPath.row]
        self.present(navController, animated: true, completion: nil)
    }
}
