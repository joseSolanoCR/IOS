//
//  Categoria.swift
//  TareaLeccion4
//
//  Created by ice on 5/2/19.
//  Copyright © 2019 personal. All rights reserved.
//

import Foundation

class Categoria{
    var nombre : String
    var imagen : String
    var noticias = [Noticia]()
    
    init(nombre: String, imagen: String){
        self.nombre = nombre
        self.imagen = imagen
    }
}
