//
//  Noticia.swift
//  TareaLeccion4
//
//  Created by ice on 5/2/19.
//  Copyright © 2019 personal. All rights reserved.
//

import Foundation

struct Noticia {
    var creacion : Date
    var titulo : String
    var cuerpo : String
}
