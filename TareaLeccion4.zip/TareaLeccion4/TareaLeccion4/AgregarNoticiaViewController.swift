//
//  AgregarNoticiaViewController.swift
//  TareaLeccion4
//
//  Created by ice on 6/2/19.
//  Copyright © 2019 personal. All rights reserved.
//

import UIKit

protocol AgregarNoticiaViewControllerDelegate: class{
    func publicarNoticia(noticia: Noticia)
}

class AgregarNoticiaViewController: UIViewController {

    weak var delegate: AgregarNoticiaViewControllerDelegate?
    
    @IBOutlet weak var txtTitulo: UITextField!
    @IBOutlet weak var txtCuerpo: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        txtCuerpo.layer.borderWidth = 1
        txtCuerpo.layer.borderColor = UIColor.gray.cgColor
    }

    @IBAction func crearNoticia(_ sender: Any) {
        if let titulo = txtTitulo.text, let cuerpo = txtCuerpo.text {
            var noticia : Noticia = Noticia(creacion: Date(), titulo: titulo ?? "", cuerpo: cuerpo)
            
            publicarNoticia(noticia: noticia)
        }else{
            showAlertController()
        }
    }
    
    func publicarNoticia(noticia: Noticia){
        delegate?.publicarNoticia(noticia: noticia)
    }
    
    func showAlertController(){
        let alertController = UIAlertController(title: "Error", message: "Debe llenar todos los campos", preferredStyle: .alert)
        let action  = UIAlertAction(title: "OK", style: .default) { (_) in
            self.txtTitulo.becomeFirstResponder()
        }
        alertController.addAction(action)
        present(alertController, animated: true, completion: nil)
    }
}
