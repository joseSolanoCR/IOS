import UIKit

func sumaParesImpares(arreglo1:[Int]){
    var pares = 0
    var impares = 0
    
    for a in arreglo1{
        if (a%2 == 0) {pares += a} else{impares += a }
        
    }
    if (pares < impares) {print("True")} else{print("FALSE")}
    
}
var arr1 =  [1,2,3,4,5]

sumaParesImpares(arreglo1: arr1)



func divisoresNum (numero : Int) -> [Int]{
    var divisores = [Int]()
    
    for posibleDivisor in 1 ..< numero{
        if (numero % posibleDivisor == 0){
            divisores.append(posibleDivisor)
        }
    }
    
    return divisores
}

func promedio (numeros : [Float]) -> Float{
    var sumatoria : Float = 0
    
    for valor in numeros{
        sumatoria += valor
    }
    
    return sumatoria / Float(numeros.count)
}


