//
//  ViewController.swift
//  tarea3
//
//  Created by Jose Pablo Solano Calderon on 22/2/19.
//  Copyright © 2019 Jose Pablo Solano Calderon. All rights reserved.
//

import UIKit
import RealmSwift

class ViewController: UIViewController {
    @IBOutlet weak var tablaArticulo: UITableView!
    @IBOutlet weak var textField: UITextField!
    var articulos:Results<Articulo>?=nil
    
    
    @IBAction func add(_ sender: Any) {
        
        let alert = UIAlertController(title: "Inserte articulo", message: "Por Favor inserte articulo", preferredStyle: UIAlertController.Style.alert)
        let action = UIAlertAction(title: "Name Input", style: .default) { (alertAction) in
            let textField = alert.textFields![0] as UITextField
        }
   
        alert.addTextField { (textField) in
            textField.placeholder = "Digite Articulo"
        }
        
    
        alert.addAction(UIAlertAction(title:"Agregar", style:UIAlertAction.Style.default, handler:{(UIAlertAction) in
            let articulo = Articulo()
            articulo.fecha = Date()
            articulo.articulo = alert.textFields?[0].text ?? "Empty"
            self.guardar(articulo: articulo)
            
        }))
        alert.addAction(UIAlertAction(title: "Cancelar", style: UIAlertAction.Style.cancel,handler:{(UIAlertAction) in }))
        
        self.present(alert, animated: true, completion: nil)
        
        
    }
    
    private func guardar(articulo:Object){
        do{
            let realm=try Realm()
            try realm.write {
                realm.add(articulo,update:true)
                self.actualizarArticulo()
            }
        }
        catch let error as NSError{print("Error eliminando\(error)")}
    }
    
    private func actualizarArticulo(){
        do{
            let realm=try Realm()
            self.articulos=realm.objects(Articulo.self)
            tablaArticulo.reloadData()
            }
        catch let error as NSError{print("Error actualizando\(error)")}
        
    }
    
    private func borrarArticulo(articulo:Object){
        do{
            let realm=try Realm()
            try realm.write {
                realm.delete(articulo)
            }
        }
        catch let error as NSError{print("Error eliminando\(error)")}
    
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        actualizarArticulo()
        registerCustomCell()
        
    }


   
}

extension ViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.articulos == nil{
            return 0
        }else{
            return self.articulos?.count ?? 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "celdaArticuloTableViewCell") as? celdaArticuloTableViewCell else {
            return UITableViewCell()
        }
        
        if let articulos = articulos {
            let articulo = articulos[indexPath.row]
            cell.setupCell(articulo:articulo)
        }
        
        return cell
    }
    
    private func registerCustomCell() {
        let nib = UINib(nibName: "celdaArticuloTableViewCell", bundle: nil)
        tablaArticulo.register(nib, forCellReuseIdentifier: "celdaArticuloTableViewCell")
    }
    
    // Metodo para borrar la celda
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        if editingStyle == .delete {
            //Borra de la BD
            self.borrarArticulo(articulo: (self.articulos?[indexPath.row])!)
            
            // Borra de la vista
            tableView.deleteRows(at: [indexPath], with: .fade)
            
        } else if editingStyle == .insert {
            //No se hace nada si falla la eliminacion
        }
    }
    
    
}
