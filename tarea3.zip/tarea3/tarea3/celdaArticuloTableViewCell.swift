//
//  celdaArticuloTableViewCell.swift
//  tarea3
//
//  Created by Jose Pablo Solano Calderon on 22/2/19.
//  Copyright © 2019 Jose Pablo Solano Calderon. All rights reserved.
//

import UIKit

class celdaArticuloTableViewCell: UITableViewCell {
    @IBOutlet weak var fecha: UILabel!

    @IBOutlet weak var producto: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func setupCell(articulo:Articulo){
        fecha.text=articulo.fecha.getFormatted(dateStyle:.medium, timeStyle:.short)
        producto.text=articulo.articulo
        
    }
}

extension Date {
    func getFormatted(dateStyle: DateFormatter.Style, timeStyle: DateFormatter.Style) -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale.current
        formatter.dateStyle = dateStyle
        formatter.timeStyle = timeStyle
        let localizedDate = formatter.string(from: self as Date)
        return localizedDate
    }
}
