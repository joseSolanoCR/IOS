//
//  Articulo.swift
//  tarea3
//
//  Created by Jose Pablo Solano Calderon on 22/2/19.
//  Copyright © 2019 Jose Pablo Solano Calderon. All rights reserved.
//

import Foundation
import RealmSwift

class Articulo:Object{
    @objc dynamic var fecha = Date()
    @objc dynamic var articulo = ""
    @objc dynamic var id =  UUID().uuidString
    
    override static func primaryKey() -> String?{return "id"}
    override static func indexedProperties() -> [String]{return["articulo"]}
    
}
