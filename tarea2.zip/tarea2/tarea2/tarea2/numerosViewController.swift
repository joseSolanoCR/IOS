//
//  ViewController.swift
//  tarea2
//
//  Created by Jose Pablo Solano on 2/13/19.
//  Copyright © 2019 Jose Pablo Solano. All rights reserved.
//

import UIKit

class numerosViewController: UIViewController {

    @IBOutlet weak var tablaNumeros: UITableView!
    
    var numeros = [Int]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        for num in 1000 ..< 2000{
            
            numeros.append(num)
            
        }
        
        func registerCustomtable(){
            let nib = UINib(nibName: "CeldaCustomYableViewCell", bundle: nil)
            tablaNumeros.register(nib, forCellReuseIdentifier: "CeldaCustomTableViewCell")
            
        }
        
    }
    
    
}

extension numerosViewController : UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return numeros.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let celda = tableView.dequeueReusableCell(withIdentifier: "CeldaCustomTableViewCell") as? CeldaCustomTableViewCell else {
            return UITableViewCell()
        }
        
        celda.label.text = String(numeros[indexPath.row])
        
        if (numeros[indexPath.row] % 2 == 0){
            celda.view.layer.backgroundColor = UIColor.blue.cgColor
        }else{
            celda.view.layer.backgroundColor = UIColor.red.cgColor
        }
        
        return celda
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150.0 //Altura de la celda
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
}

