//
//  CeldaCustomTableViewCell.swift
//  tarea2
//
//  Created by Jose Pablo Solano on 2/13/19.
//  Copyright © 2019 Jose Pablo Solano. All rights reserved.
//

import UIKit

class CeldaCustomTableViewCell: UITableViewCell {

    @IBOutlet weak var view: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    @IBOutlet weak var label: UILabel!
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
