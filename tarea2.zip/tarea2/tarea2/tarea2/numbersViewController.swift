//
//  numbersViewController.swift
//  tarea2
//
//  Created by Jose Pablo Solano on 2/13/19.
//  Copyright © 2019 Jose Pablo Solano. All rights reserved.
//

import UIKit

class numbersViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
